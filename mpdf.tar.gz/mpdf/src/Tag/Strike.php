<?php

namespace Mpdf\Tag;

class Strike extends InlineTag
{


}
